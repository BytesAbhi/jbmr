exports.AUTH_HEADER_MISSING_ERR = "auth header is missing";
exports.AUTH_TOKEN_MISSING_ERR = "auth token is missing";
exports.JWT_DECODE_ERR = "incorrect token";
exports.USER_NOT_FOUND_ERR = "User not found";
exports.ACCESS_DENIED_ERR = "Access deny for normal user";
exports.PHONE_NOT_FOUND_ERR = "Phone number not Found";
exports.PHONE_ALREADY_EXISTS_ERR = "Phone number already exists";
exports.INCORRECT_OTP_ERR    = "Incorrect OTP";


